import path from 'node:path';
import { fileURLToPath } from 'node:url';

const dir = path.dirname(fileURLToPath(import.meta.url));

const nextConfig = {
  outputFileTracingRoot: dir,
};

export default nextConfig;
